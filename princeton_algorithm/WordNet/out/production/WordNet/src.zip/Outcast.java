/**
 * Created by david on 2018/1/29.
 */
import edu.princeton.cs.algs4.ST;
public class Outcast {
    private WordNet word;
   // private ST<String,Integer> dist;
    public Outcast(WordNet wordnet){
        // constructor takes a WordNet object
        if(wordnet == null) throw new IllegalArgumentException("illegal");
        word = wordnet;
       // dist = new ST<>();
    }

    public String outcast(String[] nouns) {
        // given an array of WordNet nouns, return an outcast
        if(nouns == null) throw new IllegalArgumentException("illegal");
        int max_value = Integer.MIN_VALUE;
        String out = nouns[0];
        for (String noun : nouns) {
            int dist = 0;
            for (String another : nouns) {
                if (!noun.equals(another)) {
                    dist += word.distance(noun, another);
                }
            }
            if (dist > max_value) {
                max_value = dist;
                out = noun;
            }
        }
        return out;

    }
    public static void main(String[] args){}  // see test client below
}
